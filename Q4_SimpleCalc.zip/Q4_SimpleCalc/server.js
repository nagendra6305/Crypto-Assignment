function calculate(input) {
    
    const regex = /^What is (\d+) (plus|minus|multiplied by|divided by) (\d+)\?$/;
    const match = input.match(regex);

    if (!match) {
        console.log('Invalid input format. Please use: "What is {number} {operation} {number}?"');
        return;
    }

    const num1 = parseInt(match[1]);
    const operator = match[2];
    const num2 = parseInt(match[3]);

    let result;
    switch (operator) {
        case 'plus':
            result = num1 + num2;
            break;
        case 'minus':
            result = num1 - num2;
            break;
        case 'multiplied by':
            result = num1 * num2;
            break;
        case 'divided by':
            if (num2 === 0) {
                console.log('Error: Division by zero');
                return;
            }
            result = num1 / num2;
            break;
        default:
            console.log('Unsupported operation.');
            return;
    }

    console.log(`${num1} ${operator} ${num2} is ${result}`);
}


if (process.argv.length !== 3) {
    console.log('Usage: node index.js "What is {number} {operation} {number}?"');
} else {
    
    const input = process.argv[2];
    calculate(input);
}

//Run Command =npm start "What is 5 plus 7?"
