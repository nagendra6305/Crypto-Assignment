const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3000;


let users = [
    { id: 1, name: 'Rakesh', createdOn: '2024-07-05', gender: 'Male', dob: '1990-01-01', city: 'Hyderabad', state: 'Telangana', pincode: '505006', modifiedOn: '2024-07-05' },
    { id: 2, name: 'sumathi', createdOn: '2024-07-05', gender: 'Female', dob: '1995-05-15', city: 'Vijaywada', state: 'AndraPradesh', pincode: '505007', modifiedOn: '2024-07-05' }
];
let nextUserId = 3;

app.use(bodyParser.json());


app.get('/users', (req, res) => {
    res.json(users);
});


app.post('/users', (req, res) => {
    const newUser = {
        id: nextUserId++,
        ...req.body,
        createdOn: new Date().toISOString(),
        modifiedOn: new Date().toISOString()
    };
    users.push(newUser);
    res.status(201).json(newUser);
});


app.put('/users/:userId', (req, res) => {
    const userId = parseInt(req.params.userId);
    const updatedUser = req.body;
    let found = false;
    users = users.map(user => {
        if (user.id === userId) {
            found = true;
            return {
                ...user,
                ...updatedUser,
                modifiedOn: new Date().toISOString()
            };
        }
        return user;
    });
    if (found) {
        res.json({ message: `User with id ${userId} updated` });
    } else {
        res.status(404).json({ error:` User with id ${userId} not found `});
    }
});


app.delete('/users/:userId', (req, res) => {
    const userId = parseInt(req.params.userId);
    const initialLength = users.length;
    users = users.filter(user => user.id !== userId);
    if (users.length < initialLength) {
        res.json({message: `User with id ${userId} deleted`});
    } else {
        res.status(404).json({ error: `User with id ${userId} not found` });
    }
});

app.listen(PORT, () => {
    console.log(`User API Server is running on http://localhost:${PORT}`);
});