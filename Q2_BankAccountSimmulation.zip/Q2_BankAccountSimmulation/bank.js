var BankAccount = /** @class */ (function () {
    function BankAccount() {
        this.accountDetails = {};
        this.balance = 0;
        this.transactions = [];
    }
    BankAccount.prototype.openAccount = function (name, gender, dob, email, mobile, address, initialBalance, adharNo, panNo) {
        if (this.accountDetails.name) {
            throw new Error('Account is already open.');
        }
        this.accountDetails = {
            name: name,
            gender: gender,
            dob: dob,
            email: email,
            mobile: mobile,
            address: address,
            initialBalance: initialBalance,
            adharNo: adharNo,
            panNo: panNo
        };
        this.balance = initialBalance;
        console.log('Account opened successfully.');
    };
    BankAccount.prototype.updateKYC = function (name, dob, email, mobile, adharNo, panNo) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.accountDetails.name = name;
        this.accountDetails.dob = dob;
        this.accountDetails.email = email;
        this.accountDetails.mobile = mobile;
        this.accountDetails.adharNo = adharNo;
        this.accountDetails.panNo = panNo;
        console.log('KYC details updated successfully.');
    };
    BankAccount.prototype.depositMoney = function (amount) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.balance += amount;
        this.transactions.push({ type: 'Deposit', amount: amount, date: new Date() });
        console.log("Deposited ".concat(amount, " successfully."));
    };
    BankAccount.prototype.withdrawMoney = function (amount) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        if (this.balance < amount) {
            throw new Error('Insufficient balance.');
        }
        this.balance -= amount;
        this.transactions.push({ type: 'Withdrawal', amount: amount, date: new Date() });
        console.log("Withdrawn ".concat(amount, " successfully."));
    };
    BankAccount.prototype.transferMoney = function (toName, amount) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        if (this.balance < amount) {
            throw new Error('Insufficient balance.');
        }
        this.balance -= amount;
        this.transactions.push({ type: 'Transfer to ' + toName, amount: amount, date: new Date() });
        console.log("Transferred ".concat(amount, " to ").concat(toName, " successfully."));
    };
    BankAccount.prototype.receiveMoney = function (fromName, amount) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.balance += amount;
        this.transactions.push({ type: 'Received from ' + fromName, amount: amount, date: new Date() });
        console.log("Received ".concat(amount, " from ").concat(fromName, " successfully."));
    };
    BankAccount.prototype.printStatement = function () {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        console.log('Account Details:');
        console.log("Name: ".concat(this.accountDetails.name));
        console.log("Gender: ".concat(this.accountDetails.gender));
        console.log("Date of Birth: ".concat(this.accountDetails.dob));
        console.log("Email: ".concat(this.accountDetails.email));
        console.log("Mobile: ".concat(this.accountDetails.mobile));
        console.log("Address: ".concat(this.accountDetails.address));
        console.log("Adhar No: ".concat(this.accountDetails.adharNo));
        console.log("Pan No: ".concat(this.accountDetails.panNo));
        console.log("Balance: ".concat(this.balance));
        console.log('\nTransaction History:');
        this.transactions.forEach(function (transaction) {
            console.log("".concat(transaction.date.toISOString(), " - ").concat(transaction.type, ": ").concat(transaction.amount));
        });
    };
    BankAccount.prototype.closeAccount = function () {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.accountDetails = {};
        this.balance = 0;
        this.transactions = [];
        console.log('Account closed successfully.');
    };
    return BankAccount;
}());

var account = new BankAccount();
account.openAccount("Nagendra", 'Male', '1990-01-01', 'nagendra@gmail.com', '1234567890', 'Hyderabad, City', 1000, '123456789012', 'ABCDE1234F');
account.depositMoney(500);
account.withdrawMoney(200);
account.transferMoney('Prince', 300);
account.receiveMoney('varun', 100);
account.printStatement();
account.closeAccount();
