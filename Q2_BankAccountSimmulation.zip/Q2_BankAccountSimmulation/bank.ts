class BankAccount {
    private accountDetails: {
        name: string;
        gender: string;
        dob: string;
        email: string;
        mobile: string;
        address: string;
        initialBalance: number;
        adharNo: string;
        panNo: string;
    };
    private balance: number;
    private transactions: { type: string, amount: number, date: Date }[];

    constructor() {
        this.accountDetails = {} as any;
        this.balance = 0;
        this.transactions = [];
    }

    openAccount(
        name: string, gender: string, dob: string, email: string, mobile: string,
        address: string, initialBalance: number, adharNo: string, panNo: string
    ) {
        if (this.accountDetails.name) {
            throw new Error('Account is already open.');
        }
        this.accountDetails = {
            name,
            gender,
            dob,
            email,
            mobile,
            address,
            initialBalance,
            adharNo,
            panNo
        };
        this.balance = initialBalance;
        console.log('Account opened successfully.');
    }

    updateKYC(name: string, dob: string, email: string, mobile: string, adharNo: string, panNo: string) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.accountDetails.name = name;
        this.accountDetails.dob = dob;
        this.accountDetails.email = email;
        this.accountDetails.mobile = mobile;
        this.accountDetails.adharNo = adharNo;
        this.accountDetails.panNo = panNo;
        console.log('KYC details updated successfully.');
    }

    depositMoney(amount: number) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.balance += amount;
        this.transactions.push({ type: 'Deposit', amount, date: new Date() });
        console.log(`Deposited ${amount} successfully.`);
    }

    withdrawMoney(amount: number) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        if (this.balance < amount) {
            throw new Error('Insufficient balance.');
        }
        this.balance -= amount;
        this.transactions.push({ type: 'Withdrawal', amount, date: new Date() });
        console.log(`Withdrawn ${amount} successfully.`);
    }

    transferMoney(toName: string, amount: number) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        if (this.balance < amount) {
            throw new Error('Insufficient balance.');
        }
        this.balance -= amount;
        this.transactions.push({ type: 'Transfer to ' + toName, amount, date: new Date() });
        console.log(`Transferred ${amount} to ${toName} successfully.`);
    }

    receiveMoney(fromName: string, amount: number) {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.balance += amount;
        this.transactions.push({ type: 'Received from ' + fromName, amount, date: new Date() });
        console.log(`Received ${amount} from ${fromName} successfully.`);
    }

    printStatement() {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        console.log('Account Details:');
        console.log(`Name: ${this.accountDetails.name}`);
        console.log(`Gender: ${this.accountDetails.gender}`);
        console.log(`Date of Birth: ${this.accountDetails.dob}`);
        console.log(`Email: ${this.accountDetails.email}`);
        console.log(`Mobile: ${this.accountDetails.mobile}`);
        console.log(`Address: ${this.accountDetails.address}`);
        console.log(`Adhar No: ${this.accountDetails.adharNo}`);
        console.log(`Pan No: ${this.accountDetails.panNo}`);
        console.log(`Balance: ${this.balance}`);

        console.log('\nTransaction History:');
        this.transactions.forEach((transaction) => {
            console.log(`${transaction.date.toISOString()} - ${transaction.type}: ${transaction.amount}`);
        });
    }

    closeAccount() {
        if (!this.accountDetails.name) {
            throw new Error('Account is not yet opened.');
        }
        this.accountDetails = {} as any;
        this.balance = 0;
        this.transactions = [];
        console.log('Account closed successfully.');
    }
}

// Example Usage:
const account = new BankAccount();
account.openAccount('John Doe', 'Male', '1990-01-01', 'john.doe@example.com', '1234567890', '123 Main St, City', 1000, '123456789012', 'ABCDE1234F');
account.depositMoney(500);
account.withdrawMoney(200);
account.transferMoney('Jane Smith', 300);
account.receiveMoney('Alice Brown', 100);
account.printStatement();
account.closeAccount();
